﻿
	public interface ISetController
	{
		string PerformSets();
	}