﻿using FestivalManager.Entities.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace FestivalManager.Core.Commands
{
    public abstract class Command
    {
        //private string[] data;
        //private IStage stage;
        //private IInstrument instrumentFactory;
        //private ISet setFactory;

        private string[] data;
        private IStage stage;
        private ISet setFacrtory;
        private IInstrument instrumentFacrtory;


        protected Command(string[] data, ISet setFacrtory, IStage stage, IInstrument instrumentFacrtory)
        {
            this.Data = data;
            this.SetFacrtory = setFacrtory;
            this.Stage = stage;
            this.InstrumentFacrtory = instrumentFacrtory;
        }

        public string[] Data
        {
            get { return data; }
            set { data = value; }
        }

        public IStage Stage
        {
            get { return stage; }
            set { stage = value; }
        }

        public IInstrument InstrumentFacrtory
        {
            get { return instrumentFacrtory; }
            set { instrumentFacrtory = value; }
        }

        public ISet SetFacrtory
        {
            get { return setFacrtory; }
            set { setFacrtory = value; }
        }
    }
}