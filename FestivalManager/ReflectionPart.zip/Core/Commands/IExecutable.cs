﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FestivalManager.Core.Commands
{
    public interface IExecutable
    {
        string Execute();
    }
}