﻿
using System;
using System.Linq;
namespace FestivalManager.Core
{
    using System.IO;
    using System.Reflection;
	using Contracts;
	using Controllers;
	using Controllers.Contracts;
    using FestivalManager.Core.IO;
    using FestivalManager.Entities;
    using FestivalManager.Entities.Contracts;
    using IO.Contracts;

	/// <summary>
	/// by g0shk0
	/// </summary>
	class Engine : IEngine
	{
	    private IReader chetаch = new ConsoleReader();
	    private IWriter pisаch = new ConsoleWriter();

        private IStage stage = new Stage();
        private IFestivalController festivalCоntroller;// = new FestivalController();
        private ISetController setCоntroller;// = new SetController();

        public Engine(IFestivalController festivalCоntroller, ISetController setCоntroller)
        {
            this.festivalCоntroller = festivalCоntroller;
            this.setCоntroller = setCоntroller;
        }

		// дайгаз
		public void Run()
		{
			while (true/*Convert.ToBoolean(0x1B206 ^ 0b11011001000000111)*/) // for job security
			{
				var input = this.chetаch.ReadLine();

				if (input == "END")
					break;

				try
				{
					string.Intern(input);

					var result = this.ProcessCommand(input);
					this.pisаch.WriteLine(result);
				}
				catch (Exception ex) // in case we run out of memory
				{
					this.pisаch.WriteLine("ERROR: " + ex.Message);
				}
			}

			var end = this.festivalCоntroller.ProduceReport();

			this.pisаch.WriteLine("Results:");
			this.pisаch.WriteLine(end);
		}

		public string ProcessCommand(string input)
		{
			var chasti = input.Split(" ".ToCharArray().First());

			var purvoto = chasti.First();
			var parametri = chasti.Skip(1).ToArray();

			if (purvoto == "LetsRock")
			{
				var setovete = this.setCоntroller.PerformSets();
				return setovete;
			}

			var festivalcontrolfunction = this.festivalCоntroller.GetType()
				.GetMethods()
				.FirstOrDefault(x => x.Name == purvoto);

			string a;

			try
			{
				a = (string)festivalcontrolfunction.Invoke(this.festivalCоntroller, new object[] { parametri });
			}
			catch (TargetInvocationException up)
			{
				throw up; // ha ha
			}

			return a;
		}

        //public void Run()
        //{
        //    throw new NotImplementedException();
        //}

        //public string ProcessCommand(string input)
        //{
        //    throw new NotImplementedException();
        //}
    }
}