﻿using FestivalManager.Entities.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace FestivalManager.Entities.Sets
{
    public class TestSet : ISet
    {
        public TestSet(string name)
        {
            this.Name = name;
        }

        public string Name { get; set; }

        public TimeSpan MaxDuration { get; set; }

        public TimeSpan SetupDuration { get; set; }

        public TimeSpan ActualDuration { get; set; }

        public IReadOnlyCollection<IPerformer> Performers { get; set; }

        public IReadOnlyCollection<ISong> Songs { get; set; }

        public void AddPerformer(IPerformer performer) => throw new NotImplementedException();

        public void AddSong(ISong song) => throw new NotImplementedException();

        public bool CanPerform() => throw new NotImplementedException();
    }
}
