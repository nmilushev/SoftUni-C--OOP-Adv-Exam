﻿using System;

using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace FestivalManager.Entities.Factories
{
	using Contracts;
	using Entities.Contracts;
	using Sets;

	public class SetFactory : ISetFactory
	{
      //  private const string invalidSet = "Inavalid set type";
		public ISet CreateSet(string name, string type)
		{

            Type typeType = Assembly.GetCallingAssembly()
                .GetTypes().FirstOrDefault(t => t.Name == type);

            return (ISet)Activator.CreateInstance(typeType, new object[] { name });
			//if (type == "Short")
			//{
			//	return new Short(name);
			//}
			//else if (type == "Medium")
			//{
			//	return new Medium(name);
			//}
			//else if (type == "Long")
			//{
			//	return new Long(name);
			//}

   //         throw new ArgumentException(invalidSet);
		}
	}
}